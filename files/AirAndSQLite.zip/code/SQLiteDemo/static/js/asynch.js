

function proc(){
	dbFile = air.File.applicationStorageDirectory.resolvePath("demo.db");
	
	// open the db
	conn = new air.SQLConnection();
	conn.addEventListener(air.SQLEvent.OPEN, openHandler);
	conn.addEventListener(air.SQLErrorEvent.ERROR, errorHandler);
	conn.openAsync(dbFile);
	
	// create your sql	
	sql = "SELECT personID , firstName, lastName, email, website " 
		+ "FROM person";
	
	// put all of the pieces together
	selectStmt = new air.SQLStatement();
	selectStmt.text = sql;
	selectStmt.sqlConnection = conn;
	selectStmt.addEventListener(air.SQLEvent.RESULT, listPersons);
	selectStmt.addEventListener(air.SQLErrorEvent.ERROR, errorHandler);
	// GO!
	selectStmt.execute();
	
}

function listPersons(event)
{
    var result = selectStmt.getResult();
    var numRows = result.data.length;
   	var output = "<table>\n";
    
	//build table header
	output += "\t<thead>\n\t\t<tr>\n";
  	for (columnName in result.data[0])
    {
        output += "\t\t\t<th>" + columnName + "</th>\n";
    }
  	output += "\t\t</tr>\n\t</thead>\n";
  
  	//build table body
   	output += "\t<tbody>\n";
	
	for (i = 0; i < numRows; i++)
    {
      	output += "\t\t<tr>\n";
        for (columnName in result.data[i])
        {
            output += "\t\t\t<td>" + result.data[i][columnName] + "</td>\n";
        }
        output += "\t\t</tr>\n";
	}
	output += "\t</tbody>\n";
	output += "</table>\n";
	
	var displayLocation = document.getElementById('data') ;
	displayLocation.innerHTML = output;
	
	
	air.trace(output);
}





function openHandler(event)
{
    air.trace("The connection was created successfully");
	air.trace("File is at "+ air.File.applicationStorageDirectory.resolvePath("SQLiteDemo.db").nativePath );
}

function errorHandler(event)
{
    alert('Dude you did something wrong!');
    air.trace(event);
}