/**
 * @author tpryan
 */

function createConnection(){
	/*set the file location*/
	var dbFile = 
	air.File.applicationStorageDirectory.resolvePath("demo.db");
	
	/*Open connection to target file.*/
	var conn = new air.SQLConnection();
	conn.open(dbFile);

	/*return the connection */
	return(conn);	
}

function createDB(){
	/*set the file location*/
	var dbFile = 
	air.File.applicationStorageDirectory.resolvePath("demo.db");
	
	/*Open a connection using openAsync*/
	var conn = new air.SQLConnection();
	conn.openAsync(dbFile);
}


function createSchema(){
	
	/* Create the connection assuming you have this function*/
	var conn = createConnection();
	
	/* create a new statement*/
	var createStmt = new air.SQLStatement();
	
	/* Build the text for the statement */		
	var sql = 
	    "CREATE TABLE IF NOT EXISTS person (" + 
	    "    personID INTEGER PRIMARY KEY AUTOINCREMENT, " + 
	    "    firstName TEXT, " + 
	    "    lastName TEXT, " + 
	    "    email TEXT," + 
		"    website TEXT" + 
	    ")";
	
	/*put everything together and fire away*/
	createStmt.sqlConnection = conn;
	createStmt.text = sql;
	createStmt.execute();
}

function insertData(){
	
	/* Create the connection assuming you have this function*/
	var conn = createConnection();
	
	/* create a new insert statement*/
	var insertStmt = new air.SQLStatement();
	
	/* Just youar average ordinary insert */
	var sql = 	 "INSERT INTO person (firstName, lastName, email, website) " + 
   				 "VALUES ('Terrence', 'Ryan', 'terry@numtopia.com','http://www.numtopia.com/terry')";
	
	/*put everything together and fire away*/	
	insertStmt.sqlConnection = conn;
	insertStmt.text = sql;
	insertStmt.execute();
	
}

function retrieveData(){
	
	/* Create the connection assuming you have this function*/
	var conn = createConnection();
	
	/* create a new select statement*/
	selectStmt = new air.SQLStatement();	
	
   	
	/* Just youar average ordinary insert */
	var sql = 	 "SELECT personID, firstName, lastName, email, website FROM person"; 
	
	/*put everything together and fire away*/	
	selectStmt.text = sql;	
	selectStmt.sqlConnection = conn;
		
	selectStmt.execute();
	
}


function procSynch(){
	dbFile = air.File.applicationStorageDirectory.resolvePath("demo.db");
	
	// open the db
	conn = new air.SQLConnection();
	conn.open(dbFile);
	
	// create your sql
	sql = "SELECT personID , firstName, lastName, email, website" 
		+ "FROM person";
	
	// create your statment
	selectStmt = new air.SQLStatement();
	// put all of the pieces together
	selectStmt.text = sql;
	selectStmt.sqlConnection = conn;
	
	selectStmt.execute();
	
	// grab the results
	personList = selectStmt.getResult();
	
	// assuming listPersons does something with your results 
	listPersons(personList);
	
	
}

function procAsynch(){
	dbFile = air.File.applicationStorageDirectory.resolvePath("demo.db");
	
	// open the db
	conn = new air.SQLConnection();
	conn.addEventListener(air.SQLEvent.OPEN, openHandler);
	conn.addEventListener(air.SQLErrorEvent.ERROR, errorHandler);
	conn.openAsync(dbFile);
	
	// create your sql	
	sql = "SELECT personID , firstName, lastName, email, website" 
		+ "FROM person";
	
	// put all of the pieces together
	selectStmt = new air.SQLStatement();
	selectStmt.text = sql;
	selectStmt.sqlConnection = conn;
	selectStmt.addEventListener(air.SQLEvent.RESULT, listPersons);
	selectStmt.addEventListener(air.SQLErrorEvent.ERROR, errorHandler);
	// GO!
	selectStmt.execute();
	
}


function statement(){
	dbFile = air.File.applicationStorageDirectory.resolvePath("demo.db");
	
	// open the db
	conn = new air.SQLConnection();
	conn.open(dbFile);
			
	// create your statment
	selectStmt = new air.SQLStatement();
	// put all of the pieces together
	selectStmt.text = "SELECT * FROM PERSON";
	selectStmt.sqlConnection = conn; //Prexisting connection
	selectStmt.execute();
	
	// grab the results
	personList = selectStmt.getResult();
	
	// assuming listPersons does something with your results 
	listPersons(personList);
	
	
}

