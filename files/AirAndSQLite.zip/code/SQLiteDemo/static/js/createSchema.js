/**
 * @author tpryan
 */




function createSchema(){
	
	var conn = createConnection();
	
	var createStmt1 = new air.SQLStatement();
	var createStmt2 = new air.SQLStatement();
	var createStmt3 = new air.SQLStatement();
		
	var sql1 = 
	    "CREATE TABLE IF NOT EXISTS person (" + 
	    "    personID INTEGER PRIMARY KEY AUTOINCREMENT, " + 
	    "    firstName TEXT, " + 
	    "    lastName TEXT, " + 
	    "    email TEXT," + 
		"    website TEXT" + 
	    ")";
	var sql2 = 	"CREATE TABLE IF NOT EXISTS tag (" + 
	    "    tagID INTEGER PRIMARY KEY AUTOINCREMENT, " + 
	    "    name TEXT " + 
	    ")";
	var sql3 = 	"CREATE TABLE IF NOT EXISTS personToTag (" + 
	    "    personToTagID INTEGER PRIMARY KEY AUTOINCREMENT, " + 
	    "    personID INTEGER, " + 
		"    tagID INTEGER " + 
	    ")";
	
	createStmt1.sqlConnection = conn;
	createStmt1.addEventListener(air.SQLEvent.RESULT, createResult);
	createStmt1.addEventListener(air.SQLErrorEvent.ERROR, createError);
	createStmt1.text = sql1;
	createStmt1.execute();
	
	createStmt2.sqlConnection = conn;
	createStmt2.addEventListener(air.SQLEvent.RESULT, createResult);
	createStmt2.addEventListener(air.SQLErrorEvent.ERROR, createError);
	createStmt2.text = sql2;
	createStmt2.execute();
	
	createStmt3.sqlConnection = conn;
	createStmt3.addEventListener(air.SQLEvent.RESULT, createResult);
	createStmt3.addEventListener(air.SQLErrorEvent.ERROR, createError);
	createStmt3.text = sql3;
	createStmt3.execute();
	
}




function createResult(event)
{
    air.trace("Table created");
}

function createError(event)
{
    air.trace("Error message:", event.error.message);
    air.trace("Details:", event.error.details);
}