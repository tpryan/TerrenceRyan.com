

function proc(){
	dbFile = air.File.applicationStorageDirectory.resolvePath("demo.db");
	
	// open the db
	conn = new air.SQLConnection();
	conn.open(dbFile);
	
	// create your sql
	sql = "SELECT personID, firstName, lastName, email, website " 
		+ "FROM person";
	
	// create your statment
	selectStmt = new air.SQLStatement();
	// put all of the pieces together
	selectStmt.text = sql;
	selectStmt.sqlConnection = conn;
	
	//Putting the try and catch to handle errors.
	try{
		selectStmt.execute();
	
		// grab the results
		personList = selectStmt.getResult();
	
		// assuming listPersons does something with your results 
		listPersons(personList);
	}
	catch(error){
		alert('Dude, you did something wrong!');
		air.trace(error);
	}
	
}

function listPersons(selectResult)
{
    var result = selectResult;
    var numRows = result.data.length;
   	var output = "<table>\n";
    
    //build table header
    output += "\t<thead>\n\t\t<tr>\n";
  	for (columnName in result.data[0])
    {
        output += "\t\t\t<th>" + columnName + "</th>\n";
    }
  	output += "\t\t</tr>\n\t</thead>\n";
    output += "\t<tbody>\n";
    
    //build table body
    for (i = 0; i < numRows; i++)
    {
      	
	  output += "\t\t<tr>\n";
	   	
        for (columnName in result.data[i])
        {
            output += "\t\t\t<td>" + result.data[i][columnName] + "</td>\n";
        }
        
    	output += "\t\t</tr>\n";
	}
	output += "\t</tbody>\n";
	output += "</table>\n";
	
	var displayLocation = document.getElementById('data') ;
	displayLocation.innerHTML = output;
		
	air.trace(output);
}




