/**
 * @author tpryan
 */


function insertData(){
	
	var conn = createConnection();
	
	var insertStmt = new air.SQLStatement();
	
	var sql = 	 "INSERT INTO person (firstName, lastName, email, website) " + 
   				 "VALUES ('Terrence', 'Ryan', 'terry@numtopia.com','http://www.numtopia.com/terry')";
		
	insertStmt.sqlConnection = conn;
	insertStmt.addEventListener(air.SQLEvent.RESULT, insertResult);
	insertStmt.addEventListener(air.SQLErrorEvent.ERROR, insertError);
	insertStmt.text = sql;
	insertStmt.execute();
	
}

function insertResult(event)
{
    air.trace("INSERT statement succeeded");
}

function insertError(event)
{
    air.trace("Error message:", event.error.message);
    air.trace("Details:", event.error.details);
}