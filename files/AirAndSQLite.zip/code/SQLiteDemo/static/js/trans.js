/**
 * @author tpryan
 */


function proc(){
	// create a synchronous connection
	var conn = createConnection(asynch=false);
	
	// create your sql
	insertSQL = "INSERT INTO person(firstName, lastName, email, website) " 
		+ "VALUES(:firstName, :lastName, :email, :website)";
	
	// create your statment
	selectStmt = new air.SQLStatement();
	// put all of the pieces together
	selectStmt.text = insertSQL;
	selectStmt.sqlConnection = conn;
	
	
	
	conn.begin();
	
	//Putting the try and catch to handle errors.
	try{
		
		
		selectStmt.parameters[":firstName"] = "Janice";
		selectStmt.parameters[":lastName"] = "Ryan";
		selectStmt.parameters[":email"] = "janice@numtopia.com";
		selectStmt.parameters[":website"] = "http://www.numtopia.com/janice";
		
		selectStmt.execute();
		
		selectStmt.parameters[":firstName"] = "Casey";
		selectStmt.parameters[":lastName"] = "Ryan";
		selectStmt.parameters[":email"] = "casey@numtopia.com";
		selectStmt.parameters[":website"] = "http://www.numtopia.com/casey";
		
		
		selectStmt.execute();
		conn.commit();
		
	}
	catch(error){
		conn.rollback();
		alert('Dude you did something wrong!');
		air.trace(error);
	}
	
}




