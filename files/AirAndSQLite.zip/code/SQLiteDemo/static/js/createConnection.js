/**
 * @author tpryan
 */
function createConnection(asynch){
	
	var asynch = (asynch==null) ? true : asynch;
	
	/*Target file*/
	var dbFile = air.File.applicationStorageDirectory.resolvePath("demo.db");
	
	/*Open connection to target file.*/
	
	if (!(isDefined('conn'))) {
		conn = new air.SQLConnection();
		
		if (asynch == true) {
			conn.addEventListener(air.SQLEvent.OPEN, openHandler);
			conn.addEventListener(air.SQLErrorEvent.ERROR, errorHandler);
			conn.openAsync(dbFile);
		}
		else {
			conn.open(dbFile);
		}
	}	
	
	
	return(conn);	
}





function openHandler(event)
{
    air.trace("The connection was created successfully");
	air.trace("File is at "+ air.File.applicationStorageDirectory.resolvePath("SQLiteDemo.db").nativePath );
}

function errorHandler(event)
{
    air.trace("Error message:", event.error.message);
    air.trace("Details:", event.error.details);
}

function isDefined(variable)
{
return (!(!(document.getElementById(variable))))
}
