/**
 * @author tpryan
 */

function createDB(){
	
	/*Determine file location*/
	var dbFile = air.File.applicationStorageDirectory.resolvePath("demo.db");
	
	/*Create a connectio*/
	var conn = new air.SQLConnection();
	
	/*Append Event handlers*/
	conn.addEventListener(air.SQLEvent.OPEN, openHandler);
	conn.addEventListener(air.SQLErrorEvent.ERROR, errorHandler);
	
	/*Fire Away*/
	conn.openAsync(dbFile);

	
}


function openHandler(event)
{
    air.trace("The database was created successfully");
	air.trace("File is at "+ air.File.applicationStorageDirectory.resolvePath("SQLiteDemo.db").nativePath );
}

function errorHandler(event)
{
    air.trace("Error message:", event.error.message);
    air.trace("Details:", event.error.details);
}

