/**
 * @author tpryan
 */


function retrieveData(){
	
	var conn = createConnection(false);
	var sql = 	 "SELECT personID, firstName, lastName, email, website FROM person"; 
   	
	selectStmt = new air.SQLStatement();			
	selectStmt.text = sql;	
	selectStmt.sqlConnection = conn;
	selectStmt.addEventListener(air.SQLEvent.RESULT, listPersons);
	selectStmt.addEventListener(air.SQLEvent.RESULT, yo);
	selectStmt.addEventListener(air.SQLErrorEvent.ERROR, selectError);
	
	selectStmt.execute();
	
}


function listPersons(event)
{
    var result = selectStmt.getResult();
    var numRows = result.data.length;
   	var output = "<table>\n";
    
	//build table header
	output += "\t<thead>\n\t\t<tr>\n";
  	for (columnName in result.data[0])
    {
        output += "\t\t\t<th>" + columnName + "</th>\n";
    }
  	output += "\t\t</tr>\n\t</thead>\n";
  
  	//build table body
   	output += "\t<tbody>\n";
	
	for (i = 0; i < numRows; i++)
    {
      	output += "\t\t<tr>\n";
        for (columnName in result.data[i])
        {
            output += "\t\t\t<td>" + result.data[i][columnName] + "</td>\n";
        }
        output += "\t\t</tr>\n";
	}
	output += "\t</tbody>\n";
	output += "</table>\n";
	
	var displayLocation = document.getElementById('data') ;
	displayLocation.innerHTML = output;
	
	
	air.trace(output);
}

function selectError(event)
{
    air.trace("Error message:", event.error.message);
    air.trace("Details:", event.error.details);
}

function yo(event)
{
    air.trace("yo");
    
}