/**
 * @author tpryan
 */


conn = createConnection(false);




// set minute information statement
minutesql = "SELECT description, offset FROM minuteInfo WHERE minuteToCheck = :minuteToCheck";
selectMinuteStmt = new air.SQLStatement();
selectMinuteStmt.text = minutesql;
selectMinuteStmt.sqlConnection = conn;		


// set hour information statement
hoursql = "SELECT description FROM hourInfo WHERE hourToCheck = :hourToCheck";
selectHourStmt = new air.SQLStatement();
selectHourStmt.text = hoursql;
selectHourStmt.sqlConnection = conn;	

var iconLoadComplete = function(event)
{
    air.NativeApplication.nativeApplication.icon.bitmaps = new runtime.Array(event.target.content.bitmapData);
	air.trace('added icons');
}

//Initialize menu stuff
var iconMenu = new air.NativeMenu();
OnTopMenuItem = new air.NativeMenuItem("Always On Top");

var onTopCommand = iconMenu.addItem(OnTopMenuItem);
onTopCommand.addEventListener(air.Event.SELECT,function(event){
  toggleOnTop();
});

var exitCommand = iconMenu.addItem(new air.NativeMenuItem("Exit"));
exitCommand.addEventListener(air.Event.SELECT,function(event){
    air.NativeApplication.nativeApplication.icon.bitmaps = [];
    air.NativeApplication.nativeApplication.exit();
});



if (air.NativeApplication.supportsSystemTrayIcon) {
	iconLoad = new air.Loader();
	iconLoad.contentLoaderInfo.addEventListener(air.Event.COMPLETE,iconLoadComplete);
   	iconLoad.load(new air.URLRequest("static/icons/CE_16.png"));
	air.NativeApplication.nativeApplication.icon.tooltip = "About Time";
	 air.NativeApplication.nativeApplication.icon.menu = iconMenu;
}

if (air.NativeApplication.supportsDockIcon) {
        iconLoad.contentLoaderInfo.addEventListener(air.Event.COMPLETE,iconLoadComplete);
        iconLoad.load(new air.URLRequest("icons/CE_128.png"));
		 air.NativeApplication.nativeApplication.icon.menu = iconMenu;
       
    }



function init(){
	getTime();
	interval = setInterval("getTime()",'1000');
	
}


function getMinuteFromDB(minuteToGet){
	air.trace('minuteToGet:' + minuteToGet);
	selectMinuteStmt.parameters[":minuteToCheck"] = minuteToGet;
	selectMinuteStmt.execute();
	minuteresult = selectMinuteStmt.getResult();
	queryTraceDump(minuteresult);
	return minuteresult;
}


function getHourFromDB(hourToGet){
	air.trace('hourToGet:' + hourToGet);
	selectHourStmt.parameters[":hourToCheck"] = hourToGet;
	selectHourStmt.execute();
	hourresult = selectHourStmt.getResult();
	queryTraceDump(hourresult);
	return hourresult;
}



function getTime(){
	var ourDate = new Date();
	var Hours = ourDate.getHours();
	var Minutes = ourDate.getMinutes();
	var minuteResult = getMinuteFromDB(Minutes);
			
	minuteString = minuteResult.data[0]['description'];
	offset = minuteResult.data[0]['offset'];
	
	if (offset > 0){
		if (Hours == 12){	Hours = 1;	}
		else{	Hours = Hours + 1;	}
	}
		
	air.trace('hour:' + Hours);
	var hourResult = getHourFromDB(Hours);
	hourString = hourResult.data[0]['description'];
			
	var hourDiv = document.getElementById('hours');
	var minutesDiv = document.getElementById('minutes');
	
	hourDiv.innerHTML = hourString;
	minutesDiv.innerHTML = minuteString;
	
}






function isDefined(variable)
{
return (!(!(document.getElementById(variable))))
}


function queryTraceDump(queryresult){
	for (var i = 0; i < queryresult.data.length; i++)
    {
        for (columnName in queryresult.data[i])
        {
            air.trace(columnName +'[' + i + ']:' + queryresult.data[i][columnName]);
        }
   	}
	
}
function onMove(){
      nativeWindow.startMove();
  }

function onClose(){
      nativeWindow.close();
  }
  
  
function toggleOnTop(){
    if (nativeWindow.alwaysInFront == true) {
		nativeWindow.alwaysInFront = false;
		OnTopMenuItem.checked = false; 
	}
	else {
		nativeWindow.alwaysInFront = true;
		OnTopMenuItem.checked = true; 
	}
	
  }
  
  
//DATABASE FUNCTIONS 
function createConnection(asynch){
	
	var asynch = (asynch==null) ? true : asynch;
	
	dir = air.File.applicationDirectory;
	dbFile = dir.resolvePath("static/db/times.db");
	
	
	/*Open connection to target file.*/
	
	if (!(isDefined('conn'))) {
		conn = new air.SQLConnection();
		
		if (asynch == true) {
			conn.addEventListener(air.SQLEvent.OPEN, openHandler);
			conn.addEventListener(air.SQLErrorEvent.ERROR, errorHandler);
			conn.openAsync(dbFile);
		}
		else {
			conn.open(dbFile);
		}
	}	

	
	return(conn);	
}

function openHandler(event)
{
    air.trace("The connection was created successfully");
	air.trace("File is at "+ dir.resolvePath("static/db/times.db").nativePath );
}

function errorHandler(event)
{
    air.trace("Error message:", event.error.message);
    air.trace("Details:", event.error.details);
}   